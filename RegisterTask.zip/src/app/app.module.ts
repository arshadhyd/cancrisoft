import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { RegistrationFormComponent } from './registration-form/registration-form.component';



import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DataTablesModule } from 'angular-datatables';


import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {HttpClientModule, HttpClient} from '@angular/common/http';
import { ThankYouPageComponent } from './thank-you-page/thank-you-page.component';
import { RegistrationFormListComponent } from './registration-form-list/registration-form-list.component';



@NgModule({
  declarations: [
    AppComponent,
    RegistrationFormComponent,
    ThankYouPageComponent,
    RegistrationFormListComponent
  
    
  ],
  imports: [
    DataTablesModule,
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
