import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-registration-form',
  templateUrl: './registration-form.component.html',
  styleUrls: ['./registration-form.component.css']
})
export class RegistrationFormComponent implements OnInit {

  constructor(
    private formb: FormBuilder,
    private router: Router,
    



  ) { }



  submitted: boolean = false
  emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";


  reister = this.formb.group(
    {
    
      Name: [,Validators.required],
      mobilenumber: [,Validators.required],
      email: ['', [Validators.required, Validators.pattern(this.emailPattern)]],
      image: ['']
        
    }
  )
  Rdata:any
  RdataArr= Array()

  hide:boolean=false
  submit()
{
  this.submitted = true;
  if (this.reister.invalid) {
    return    console.log("Error");
  }
  console.log(this.reister.value)
  this.Rdata= this.reister.value
  this.RdataArr.push(this.Rdata)
  localStorage.setItem('Register data', JSON.stringify(this.RdataArr));
  // this.router.navigate(['ThankYouPage' ,]);
 
  $('#ShowRegister').css('display', 'none')
  $('#ShowRegisterShow').css('display', 'block')

  this.get()
  this.reister.reset();
  this.submitted=false
  


}



storedValue:any
storedValueArr:any
LastRecored:any
get()
{

  this.storedValue = localStorage.getItem("Register data");

    this.storedValueArr= JSON.parse(this.storedValue);
  
    console.log( this.storedValueArr,"get");

    this.LastRecored = this.RdataArr.slice(-1)[0]
    console.log(this.LastRecored,"afaf");
    

}

ReOpenRegisrationForm(){
  $('#ShowRegister').css('display', 'block')
  $('#ShowRegisterShow').css('display', 'none')

}

//url; //Angular 8
url: any; //Angular 11, for stricter type
msg = "";


selectFile(event: any) { //Angular 11, for stricter type
  if(!event.target.files[0] || event.target.files[0].length == 0) {
    this.msg = 'You must select an image';
    return;
  }
  
  var mimeType = event.target.files[0].type;
  
  
  if (mimeType.match(/image\/*/) == null) {
    this.msg = "Only images are supported";
    return;
  }
  
  var reader = new FileReader();
  reader.readAsDataURL(event.target.files[0]);
  
 
  reader.onload = (_event) => {
    this.reister.patchValue({})
    this.msg = "";
    this.url = reader.result; 
    
  }
}


  ngOnInit(): void {
    this.get()
  }

}
