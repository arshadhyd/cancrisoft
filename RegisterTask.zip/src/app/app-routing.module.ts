import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegistrationFormListComponent } from './registration-form-list/registration-form-list.component';
import { RegistrationFormComponent } from './registration-form/registration-form.component';
import { ThankYouPageComponent } from './thank-you-page/thank-you-page.component';

const routes: Routes = [

  {path : "RegistrationForm" ,component:RegistrationFormComponent},
  {path : "ThankYouPage" ,component:ThankYouPageComponent},
  {path : "RegistrationFormList" ,component:RegistrationFormListComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
