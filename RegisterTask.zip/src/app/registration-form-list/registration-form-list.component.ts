import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registration-form-list',
  templateUrl: './registration-form-list.component.html',
  styleUrls: ['./registration-form-list.component.css']
})
export class RegistrationFormListComponent implements OnInit {

  constructor() { }

  storedValue:any
  storedValueArr:any
  get()
  {
  
    this.storedValue = localStorage.getItem("Register data");

    this.storedValueArr= JSON.parse(this.storedValue);
  
    console.log( this.storedValueArr,"fgfg");
    
  
  }
  
  search(j:any){

       var a =$('#search').val()
       console.log(a ,";akj;fk;");
       
       if(a === this.storedValueArr.Name)
       {
        
       }

  }
  
    ngOnInit(): void {
  
      this.get()
      
    }
  }