import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thank-you-page',
  templateUrl: './thank-you-page.component.html',
  styleUrls: ['./thank-you-page.component.css']
})
export class ThankYouPageComponent implements OnInit {

  constructor() { }

  storedValue:any
  get()
  {
    this.storedValue = localStorage.getItem("Register data");
    console.log(this.storedValue,"fgfg");
  }
    ngOnInit(): void {
      this.get()
    }
  }